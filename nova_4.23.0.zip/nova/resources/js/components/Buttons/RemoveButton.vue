<template>
  <button
    type="button"
    class="rounded-full shadow bg-white dark:bg-gray-800 text-center flex items-center justify-center h-[20px] w-[21px]"
  >
    <Icon
      type="x-circle"
      :solid="true"
      class="text-gray-800 dark:text-gray-200"
    />
  </button>
</template>

<script setup>
//
</script>
